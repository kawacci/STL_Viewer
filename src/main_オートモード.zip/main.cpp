#include <M5Unified.h>
#include <SPI.h>
#include <SD.h>
#include <vector>
#include <algorithm>
#include <math.h>

#define SD_SPI_CS_PIN 42
#define SD_SPI_SCK_PIN 43
#define SD_SPI_MOSI_PIN 44
#define SD_SPI_MISO_PIN 39

#define VIEW_W 720
#define VIEW_H 720
#define UI_H 560
#define TILE_W 720
#define TILE_H 80
#define TILE_COUNT 9

LGFX_Sprite canvas(&M5.Display);

struct Triangle
{
    float v[3][3];
    float normal[3]; // 法線ベクトルを追加
};
std::vector<Triangle> model;
float angleX = 0, angleY = 0;
float offsetX, offsetY, offsetZ;

// 光源の方向ベクトル (右上・手前)
const float lightDir[3] = {0.577f, 0.577f, 0.577f}; 

bool loadSTL(const char *path)
{
    if (!SD.exists(path)) return false;
    File file = SD.open(path, FILE_READ);
    if (!file) return false;
    
    file.seek(80);
    uint32_t count;
    file.read((uint8_t *)&count, 4);
    model.clear();
    
    float minX = 1e6, maxX = -1e6, minY = 1e6, maxY = -1e6, minZ = 1e6, maxZ = -1e6;
    for (uint32_t i = 0; i < count; i++)
    {
        Triangle tri;
        uint16_t d;
        file.read((uint8_t *)tri.normal, 12); // 法線を読み込む
        file.read((uint8_t *)tri.v, 36);
        file.read((uint8_t *)&d, 2);
        
        for (int j = 0; j < 3; j++)
        {
            minX = std::min(minX, tri.v[j][0]);
            maxX = std::max(maxX, tri.v[j][0]);
            minY = std::min(minY, tri.v[j][1]);
            maxY = std::max(maxY, tri.v[j][1]);
            minZ = std::min(minZ, tri.v[j][2]);
            maxZ = std::max(maxZ, tri.v[j][2]);
        }
        model.push_back(tri);
    }
    file.close();
    offsetX = (minX + maxX) / 2.0f;
    offsetY = (minY + maxY) / 2.0f;
    offsetZ = (minZ + maxZ) / 2.0f;
    return true;
}

void drawUI()
{
    uint16_t panelCol = M5.Display.color565(20, 20, 22);
    M5.Display.fillRect(0, 0, 720, UI_H, panelCol);
    M5.Display.setTextColor(TFT_LIGHTGREY);
    M5.Display.setTextDatum(top_center);
    M5.Display.setFont(&fonts::FreeSansBoldOblique18pt7b);
    M5.Display.drawString("M5-3D SHADED VIEWER", 360, 60);
    M5.Display.drawFastHLine(100, 120, 520, TFT_DARKGREY);
    
    M5.Display.setFont(&fonts::FreeSans12pt7b);
    M5.Display.setTextColor(TFT_WHITE);
    M5.Display.drawString("RENDER: FLAT SHADING", 360, 160);
    M5.Display.setCursor(360 - 100, 200); 
    M5.Display.printf("POLYGONS: %d", model.size());
}

void setup()
{
    auto cfg = M5.config();
    M5.begin(cfg);
    M5.Display.setRotation(2);
    M5.Display.fillScreen(TFT_BLACK);

    SPI.begin(SD_SPI_SCK_PIN, SD_SPI_MISO_PIN, SD_SPI_MOSI_PIN, SD_SPI_CS_PIN);
    SD.begin(SD_SPI_CS_PIN, SPI, 25000000);
    
    // 最適化したファイルを使用
    // loadSTL("/M5-3D_clean.stl");
    loadSTL("/M5-3D.stl");

    drawUI();

    canvas.setColorDepth(16);
    if (!canvas.createSprite(TILE_W, TILE_H)) {
        while (1);
    }
}

void loop()
{
    M5.update();

    float sX = sin(angleX), cX = cos(angleX);
    float sY = sin(angleY), cY = cos(angleY);
    int viewCenterX = 360;
    int viewCenterY = UI_H + 360;

    struct DrawTri {
        int px[3], py[3];
        int minY, maxY;
        float avgZ;
        uint16_t color;
    };
    std::vector<DrawTri> drawList;
    drawList.reserve(model.size());

    for (const auto &tri : model)
    {
        // 1. 法線の回転計算（面の向きを更新）
        float nx = tri.normal[0], ny = tri.normal[1], nz = tri.normal[2];
        float tny = ny * cX - nz * sX;
        float tnz = ny * sX + nz * cX;
        float rnx = nx * cY + tnz * sY;
        float rnz = -nx * sY + tnz * cY;
        float rny = tny;

        // 2. ライトとの角度（内積）による輝度計算
        float dot = rnx * lightDir[0] + rny * lightDir[1] + rnz * lightDir[2];
        float intensity = std::max(0.1f, dot); // 陰の部分も少し明るく
        uint8_t val = (uint8_t)(intensity * 230 + 25);
        uint16_t faceColor = M5.Display.color565(val, val, val);

        DrawTri dt;
        float sumZ = 0;
        for (int i = 0; i < 3; i++)
        {
            float x = tri.v[i][0] - offsetX;
            float y = tri.v[i][1] - offsetY;
            float z = tri.v[i][2] - offsetZ;

            float ty = y * cX - z * sX;
            float tz = y * sX + z * cX;
            float tx = x * cY + tz * sY;
            float rz = -x * sY + tz * cY;

            float dist = rz + 750.0f; 
            float scale = 3500.0f / dist;

            dt.px[i] = (int)(tx * scale) + viewCenterX;
            dt.py[i] = (int)(ty * scale) + viewCenterY;
            sumZ += rz;
        }

        // 3. 背面カリング（隠面消去）
        long cp = (long)(dt.px[1] - dt.px[0]) * (dt.py[2] - dt.py[0]) -
                  (long)(dt.py[1] - dt.py[0]) * (dt.px[2] - dt.px[0]);
        if (cp <= 0) continue;

        dt.avgZ = sumZ / 3.0f;
        dt.color = faceColor;
        dt.minY = std::min({dt.py[0], dt.py[1], dt.py[2]});
        dt.maxY = std::max({dt.py[0], dt.py[1], dt.py[2]});
        drawList.push_back(dt);
    }

    std::sort(drawList.begin(), drawList.end(), [](const DrawTri &a, const DrawTri &b) {
        return a.avgZ < b.avgZ; 
    });

    for (int i = 0; i < TILE_COUNT; i++) {
        int abs_y_start = UI_H + (i * TILE_H);
        int abs_y_end = abs_y_start + TILE_H;

        canvas.fillSprite(TFT_BLACK);

        for (const auto &dt : drawList) {
            if (dt.maxY >= abs_y_start && dt.minY < abs_y_end) {
                canvas.fillTriangle(dt.px[0], dt.py[0] - abs_y_start,
                                    dt.px[1], dt.py[1] - abs_y_start,
                                    dt.px[2], dt.py[2] - abs_y_start, dt.color);
            }
        }
        canvas.pushSprite(0, abs_y_start);
    }
    angleX += 0.02f;
    angleY += 0.01f;
}